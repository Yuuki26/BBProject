package com.bb;

public class StartButton extends GameButton {
    public StartButton() {
        super("START");
    }
}
