package com.bb;

public class SettingsButton extends GameButton {
    public SettingsButton() {
        super("SETTINGS");
    }
}
