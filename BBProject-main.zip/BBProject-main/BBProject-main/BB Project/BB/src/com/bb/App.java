package com.bb;

public class App {
    public static void main(String[] args) throws Exception {
        Test.Test.main(args);  // Call the Test class main method
        System.out.println("Hello, World!");
    }
}
