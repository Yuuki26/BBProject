package Ships;

public interface Calculations {
    float DamageToShips();
    float DamageFromShips();
    int DetectionRange();


}
