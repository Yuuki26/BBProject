package Ships;

public interface Ships_Type {
    int getHP();
    int getShields();
    int getDMG();
    int getShots();
    int getPenetration();
    int DetectionRange();
    int getSize();
    String getImage();
}
