package Ships;

import java.util.List;

public class FleetCalculation implements Calculations{
    private List<Ship_Placement> placements;
    public FleetCalculation(List<Ship_Placement> placements){

        this.placements = placements;
    }
    @Override
   public float DamageToShips(){
        if (placements==null){
            return 0f;
        }
        float AVRDGM=0f;
        int count=0;
        float pen=0f;
        for(Ship_Placement p:placements){
            Ships_Type s= p.getShip();
                if(s==null){continue;}
                AVRDGM +=s.getDMG();
                count++;

            if (s.getPenetration() > s.getShields()) pen++;
        }
        if (count == 0) return 0f;
        AVRDGM = AVRDGM / count;
        float penetratedFlag = (pen >= (count + 1) / 2) ? 1f : 0f; // >=50% -> 1
        return AVRDGM * penetratedFlag * 0.8f;
    }
    public float DamageFromShips(){
        return 0f;
    };
    public int DetectionRange(){
        return 0;
    };

};

