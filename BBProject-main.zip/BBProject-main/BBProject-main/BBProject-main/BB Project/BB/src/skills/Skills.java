package skills;

import com.bb.GameLayout;

public interface Skills {
    String getName();
    String getDescription();
     String getImage();
    float modify_DMG();
    float modify_shield();
    float modify_HP();

}
